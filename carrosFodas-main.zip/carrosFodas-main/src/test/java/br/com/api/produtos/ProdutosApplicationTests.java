package br.com.api.produtos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
